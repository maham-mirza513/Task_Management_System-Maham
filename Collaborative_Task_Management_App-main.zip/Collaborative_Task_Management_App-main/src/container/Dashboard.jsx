import AddTask from "../components/AddTask";

// import Navbar from "../components/Navbar";
const Dashboard = () => {
  // const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Check authentication status when the component mounts
  // useEffect(() => {
  //   const token = localStorage.getItem('token');
  //   setIsLoggedIn(!!token); // Set isLoggedIn to true if token exists
  // }, []);

  return (
    <div>
      <h1>Welcome to our Dashboard</h1>
    </div>
  );
};

export default Dashboard;
